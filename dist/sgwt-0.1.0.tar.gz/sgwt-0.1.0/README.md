# sparse-sgwt

A Collection of SGWT Functions for Large Sparse Networks

## About

Currently under construction at the moment, but a minimum viable code example is available.

## Installation

More details will be added on specific versions for this python implementation.

- Python 3.8
- scikit-sparse 


https://github.com/scikit-sparse/scikit-sparse


First

conda install -c conda-forge scikit-sparse

Then we need to enfore these versions for now
- scipy
```
pip install --force-reinstall "scipy<=1.9.1"
```
- numpy
```
pip install --force-reinstall "numpy<=1.23.2"
```
